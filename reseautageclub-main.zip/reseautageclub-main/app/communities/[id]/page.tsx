import CommunityDetailClient from './community-detail-client';

export function generateStaticParams() {
  return [];
}

export default function CommunityDetailPage() {
  return <CommunityDetailClient />;
}
