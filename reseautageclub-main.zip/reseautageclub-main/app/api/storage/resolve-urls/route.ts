import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

export const dynamic = 'force-dynamic';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;

interface ResolveRequest {
  references: string[];
  expiresIn?: number;
}

interface ResolveResponse {
  urls: Record<string, string>;
  errors: Record<string, string>;
}

function parseStorageReference(reference: string): { bucket: string; path: string } | null {
  if (!reference) return null;

  if (reference.startsWith('user-media:')) {
    return {
      bucket: 'user-media',
      path: reference.replace('user-media:', ''),
    };
  }

  if (reference.startsWith('websiteconfig:')) {
    return {
      bucket: 'websiteconfig',
      path: reference.replace('websiteconfig:', ''),
    };
  }

  const patterns = [
    /\/storage\/v1\/object\/public\/user-media\/(.+)$/,
    /\/storage\/v1\/object\/public\/users-medias\/(.+)$/,
    /\/storage\/v1\/object\/sign\/user-media\/(.+)\?/,
  ];

  for (const pattern of patterns) {
    const match = reference.match(pattern);
    if (match) {
      return {
        bucket: 'user-media',
        path: match[1],
      };
    }
  }

  return null;
}

export async function POST(request: NextRequest) {
  try {
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey);

    const body: ResolveRequest = await request.json();
    const { references, expiresIn = 3600 } = body;

    if (!Array.isArray(references)) {
      return NextResponse.json({ error: 'Invalid request: references must be an array' }, { status: 400 });
    }

    const result: ResolveResponse = {
      urls: {},
      errors: {},
    };

    for (const reference of references) {
      if (!reference) {
        result.urls[reference] = '';
        continue;
      }

      if (reference.startsWith('http://') || reference.startsWith('https://')) {
        result.urls[reference] = reference;
        continue;
      }

      const parsed = parseStorageReference(reference);
      if (!parsed) {
        result.urls[reference] = reference;
        continue;
      }

      try {
        if (parsed.bucket === 'websiteconfig') {
          const { data } = supabaseAdmin.storage.from(parsed.bucket).getPublicUrl(parsed.path);
          result.urls[reference] = data.publicUrl;
        } else if (parsed.bucket === 'user-media') {
          const { data, error } = await supabaseAdmin.storage
            .from('user-media')
            .createSignedUrl(parsed.path, expiresIn);

          if (error) {
            result.errors[reference] = error.message;
            result.urls[reference] = '';
          } else {
            result.urls[reference] = data.signedUrl;
          }
        }
      } catch (error: any) {
        result.errors[reference] = error.message || 'Unknown error';
        result.urls[reference] = '';
      }
    }

    return NextResponse.json(result);
  } catch (error: any) {
    console.error('Error in resolve-urls route:', error);
    return NextResponse.json({ error: error.message || 'Internal server error' }, { status: 500 });
  }
}
