import { createClient } from '@supabase/supabase-js';
import { getEnvConfig } from './env-config';

const { supabaseUrl, supabaseAnonKey } = getEnvConfig();

if (typeof window !== 'undefined') {
  console.log('Supabase client initialized with:', {
    url: supabaseUrl,
    keyLength: supabaseAnonKey?.length || 0,
    keyPreview: supabaseAnonKey ? supabaseAnonKey.substring(0, 20) + '...' : 'MISSING',
  });
}

if (!supabaseUrl || !supabaseAnonKey) {
  console.error('CRITICAL: Missing Supabase credentials!', {
    url: supabaseUrl || 'MISSING',
    key: supabaseAnonKey ? 'Present' : 'MISSING',
  });
  throw new Error('Missing Supabase credentials. Please check your environment variables.');
}

export const supabase = createClient(
  supabaseUrl,
  supabaseAnonKey,
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
      storage: typeof window !== 'undefined' ? window.localStorage : undefined,
      storageKey: 'reseautageclub-auth',
      flowType: 'pkce',
    },
    global: {
      headers: {
        'X-Client-Info': 'reseautageclub-web',
        'apikey': supabaseAnonKey,
      },
    },
    db: {
      schema: 'public',
    },
    realtime: {
      params: {
        eventsPerSecond: 10,
      },
    },
  }
);
