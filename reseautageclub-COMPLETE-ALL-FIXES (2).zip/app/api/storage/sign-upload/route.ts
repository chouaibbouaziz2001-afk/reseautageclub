import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { validatePath, generateSecureFilename, getExtensionFromContentType } from '@/lib/file-validation';

export const dynamic = 'force-dynamic';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

// Rate limiting map (in production, use Redis)
const uploadAttempts = new Map<string, { count: number; resetTime: number }>();
const MAX_UPLOADS_PER_MINUTE = 10;

export async function POST(request: NextRequest) {
  try {
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey);

    const authHeader = request.headers.get('authorization');
    if (!authHeader) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    }

    const token = authHeader.replace('Bearer ', '');
    const supabaseClient = createClient(supabaseUrl, supabaseAnonKey);

    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(token);

    if (authError || !user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    }

    // Rate limiting check
    const now = Date.now();
    const userAttempts = uploadAttempts.get(user.id);

    if (userAttempts) {
      if (now < userAttempts.resetTime) {
        if (userAttempts.count >= MAX_UPLOADS_PER_MINUTE) {
          return NextResponse.json({ error: 'Rate limit exceeded' }, { status: 429 });
        }
        userAttempts.count++;
      } else {
        uploadAttempts.set(user.id, { count: 1, resetTime: now + 60000 });
      }
    } else {
      uploadAttempts.set(user.id, { count: 1, resetTime: now + 60000 });
    }

    const { bucket, contentType } = await request.json();

    if (!bucket || !contentType) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Validate bucket
    const allowedBuckets = ['user-media', 'websiteconfig'];
    if (!allowedBuckets.includes(bucket)) {
      return NextResponse.json({ error: 'Invalid bucket' }, { status: 400 });
    }

    // Generate secure filename
    const extension = getExtensionFromContentType(contentType);
    const secureFilename = generateSecureFilename(extension);

    // Build path with user ID
    const path = bucket === 'user-media' ? `${user.id}/${secureFilename}` : secureFilename;

    // Validate path
    const pathValidation = validatePath(path, user.id, bucket);
    if (!pathValidation.valid) {
      return NextResponse.json({ error: pathValidation.error }, { status: 400 });
    }

    const { data, error } = await supabaseAdmin.storage
      .from(bucket)
      .createSignedUploadUrl(path);

    if (error) {
      console.error('[API] Error creating signed upload URL:', {
        message: error.message,
        name: error.name,
      });
      return NextResponse.json({ error: 'Failed to create upload URL' }, { status: 500 });
    }

    return NextResponse.json({
      uploadUrl: data.signedUrl,
      objectPath: data.path,
      token: data.token,
      storageReference: `${bucket}:${data.path}`,
      contentType,
    });
  } catch (error: any) {
    console.error('[API] Unexpected error in sign-upload route:', {
      message: error.message,
      stack: error.stack,
    });
    return NextResponse.json({ error: 'Upload failed' }, { status: 500 });
  }
}
