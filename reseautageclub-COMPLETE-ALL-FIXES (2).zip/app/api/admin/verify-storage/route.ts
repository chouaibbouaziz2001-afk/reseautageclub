import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

export const dynamic = 'force-dynamic';
export const maxDuration = 60;

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;

interface TableStats {
  table: string;
  totalRows: number;
  rowsWithMedia: number;
  storageReferences: number;
  httpUrls: number;
  base64Data: number;
  filesVerified: number;
  filesFailed: number;
  errors: string[];
}

async function verifyTable(
  supabase: any,
  tableName: string,
  mediaColumns: string[]
): Promise<TableStats> {
  const stats: TableStats = {
    table: tableName,
    totalRows: 0,
    rowsWithMedia: 0,
    storageReferences: 0,
    httpUrls: 0,
    base64Data: 0,
    filesVerified: 0,
    filesFailed: 0,
    errors: [],
  };

  try {
    const { data: rows, error } = await supabase
      .from(tableName)
      .select(`id, ${mediaColumns.join(', ')}`)
      .limit(100);

    if (error) {
      stats.errors.push(`Failed to fetch: ${error.message}`);
      return stats;
    }

    stats.totalRows = rows.length;

    for (const row of rows) {
      let hasMedia = false;

      for (const column of mediaColumns) {
        const value = row[column];
        if (!value) continue;

        hasMedia = true;

        if (value.startsWith('data:')) {
          stats.base64Data++;
        } else if (value.startsWith('user-media:') || value.startsWith('media:') || value.startsWith('websiteconfig:')) {
          stats.storageReferences++;

          const parts = value.split(':');
          if (parts.length === 2) {
            const [bucket, path] = parts;

            try {
              if (bucket === 'user-media') {
                const { data, error } = await supabase.storage
                  .from('user-media')
                  .createSignedUrl(path, 60);

                if (error) {
                  stats.filesFailed++;
                  stats.errors.push(`${tableName}.${column}: ${path} - ${error.message}`);
                } else {
                  const response = await fetch(data.signedUrl, { method: 'HEAD' });
                  if (response.ok) {
                    stats.filesVerified++;
                  } else {
                    stats.filesFailed++;
                    stats.errors.push(`${tableName}.${column}: ${path} - HTTP ${response.status}`);
                  }
                }
              } else {
                const { data } = supabase.storage.from(bucket).getPublicUrl(path);
                const response = await fetch(data.publicUrl, { method: 'HEAD' });
                if (response.ok) {
                  stats.filesVerified++;
                } else {
                  stats.filesFailed++;
                  stats.errors.push(`${tableName}.${column}: ${path} - HTTP ${response.status}`);
                }
              }
            } catch (err: any) {
              stats.filesFailed++;
              stats.errors.push(`${tableName}.${column}: ${path} - ${err.message}`);
            }
          }
        } else if (value.startsWith('http://') || value.startsWith('https://')) {
          stats.httpUrls++;
        }
      }

      if (hasMedia) {
        stats.rowsWithMedia++;
      }
    }
  } catch (err: any) {
    stats.errors.push(`Exception: ${err.message}`);
  }

  return stats;
}

export async function GET(request: NextRequest) {
  try {
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey);

    const tablesToVerify = [
      { table: 'posts', columns: ['image_url', 'video_url'] },
      { table: 'community_posts', columns: ['image_url', 'video_url', 'audio_url'] },
      { table: 'community_chat_messages', columns: ['media_url'] },
      { table: 'admin_chat_messages', columns: ['media_url'] },
      { table: 'cofounder_messages', columns: ['media_url'] },
      { table: 'events', columns: ['cover_image_url'] },
      { table: 'communities', columns: ['avatar_url'] },
      { table: 'user_rooms', columns: ['avatar_url'] },
    ];

    const results: TableStats[] = [];

    for (const config of tablesToVerify) {
      const stats = await verifyTable(supabaseAdmin, config.table, config.columns);
      results.push(stats);
    }

    const summary = {
      totalTables: results.length,
      totalRows: results.reduce((sum, s) => sum + s.totalRows, 0),
      totalWithMedia: results.reduce((sum, s) => sum + s.rowsWithMedia, 0),
      totalStorageRefs: results.reduce((sum, s) => sum + s.storageReferences, 0),
      totalHttpUrls: results.reduce((sum, s) => sum + s.httpUrls, 0),
      totalBase64: results.reduce((sum, s) => sum + s.base64Data, 0),
      totalVerified: results.reduce((sum, s) => sum + s.filesVerified, 0),
      totalFailed: results.reduce((sum, s) => sum + s.filesFailed, 0),
      profilesExcluded: true,
    };

    const allErrors = results.flatMap(r => r.errors);

    return NextResponse.json({
      summary,
      tables: results,
      errors: allErrors,
      success: summary.totalBase64 === 0 && summary.totalFailed === 0,
    });
  } catch (error: any) {
    console.error('Error in verify-storage route:', error);
    return NextResponse.json({ error: error.message || 'Internal server error' }, { status: 500 });
  }
}
